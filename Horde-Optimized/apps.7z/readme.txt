GPH were nice enough to include USB networking module in the Caanoo firmware,
so this is simple script will just load it up and set up usb0 interface, and
start telnet server which is also in firmware.

This is intended to be used with included USB cable to set up network to a PC
(note that this will most likely only work with Linux PC, but I've not
confirmed that).

Usage:
Edit the IP address in the script as needed.
Copy the contents of this zip to apps directory on SD card, then run it on
device using menu. Now PC should see it as USB ethernet device.

