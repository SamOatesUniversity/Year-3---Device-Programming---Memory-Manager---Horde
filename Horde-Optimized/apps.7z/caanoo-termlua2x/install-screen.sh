mkdir -p /usr/local/share/terminfo/l/
mkdir -p /usr/local/share/terminfo/s/
cp linux.ti /usr/local/share/terminfo/l/linux
cp screen.ti /usr/local/share/terminfo/s/screen
